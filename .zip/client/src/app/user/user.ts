export class User {

	name: String = '';
	createdAt: Date;
	updatedAt: Date;

	constructor() {
		this.name="";
	}
}
