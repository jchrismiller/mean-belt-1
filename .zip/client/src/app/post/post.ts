export class Post {
	title: string;
	content: string;
	createdAt: Date;
	updatedAt: Date;
}
